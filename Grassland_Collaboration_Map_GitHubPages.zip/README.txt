Grassland Research Collaboration Network (2000–2026)

GitHub Pages setup:
1. Create a PUBLIC repository on GitHub.
2. Upload index.html to the repository root and commit the changes.
3. Open Settings > Pages.
4. Under Build and deployment, choose "Deploy from a branch".
5. Select branch "main" and folder "/ (root)", then Save.
6. Wait for the published site URL to appear in Settings > Pages.
7. Open the URL in a private/incognito window or phone to test it.
8. Send the working public URL to ChatGPT to generate the QR code.

Note: The page loads Leaflet, Bootstrap, and map tiles from external services, so visitors need an internet connection.
